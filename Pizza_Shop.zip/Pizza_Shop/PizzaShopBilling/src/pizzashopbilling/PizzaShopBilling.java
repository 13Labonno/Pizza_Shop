
package pizzashopbilling;


public class PizzaShopBilling {

   
    public static void main(String[] args) {
       
    }
    
}
