
package pizzashopbilling;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;


public class Items extends javax.swing.JFrame {

    
    public Items() {
        initComponents();
        ShowProducts();
        
    }

  ResultSet rs=null,rs1=null;
    Connection con=null;
    Statement st=null,st1=null;
   
    @SuppressWarnings("unchecked")
    int PrNum;
    private void CountProd(){
        try{
            st1=con.createStatement();
            rs1=st1.executeQuery("select Max(PNum) from ProductTable");
            rs1.next();
            PrNum=rs1.getInt(1)+1;
        }
        catch(Exception e){
            
        }
    }
    private void ShowProducts(){
       try{
          
           con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pizza","root","root");
           st=con.createStatement();
           rs=st.executeQuery("select*from ProductTable");
          

          Productlist.setModel(DbUtils.resultSetToTableModel(rs));
       
       }
catch(Exception e) {
    
} 
   }
     private void FilterProducts(){
       try{
          
           con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pizza","root","root");
           st=con.createStatement();
           rs=st.executeQuery("select*from ProductTable where Category='"+FilterCb.getSelectedItem().toString()+"'");
          

          Productlist.setModel(DbUtils.resultSetToTableModel(rs));
       
       }
catch(Exception e) {
     JOptionPane.showMessageDialog(this,e);
} 
   }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        prName = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        prPrc = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        prCategory = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        FilterCb = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Addbtn = new javax.swing.JButton();
        Deletebtn = new javax.swing.JButton();
        Editbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Productlist = new javax.swing.JTable();
        Refreshbtn = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setText("L.P.A Pizza Shop Management");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(304, 31, 539, 55));

        prName.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel1.add(prName, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 205, 172, 33));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("Name");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 155, 89, -1));
        jPanel1.add(prPrc, new org.netbeans.lib.awtextra.AbsoluteConstraints(819, 205, 157, 38));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setText("Category");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(431, 142, 113, -1));

        prCategory.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        prCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chicago Style", "Brick Oven Pizza", "Italian Pizza", "Neapolitan Pizza", "California Pizza", "New Yord Style Pizza", "Sicilian Pizza", "Greek Pizza", "Detroit Pizza", "Bagel Pizza", "French Break Pizza" }));
        jPanel1.add(prCategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(431, 199, -1, 38));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setText("Price");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(819, 142, 78, -1));

        FilterCb.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        FilterCb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chicago Style", "Brick Oven Pizza", "Italian Pizza", "Neapolitan Pizza", "California Pizza", "New Yord Style Pizza", "Sicilian Pizza", "Greek Pizza", "Detroit Pizza", "Bagel Pizza", "French Break Pizza" }));
        FilterCb.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                FilterCbItemStateChanged(evt);
            }
        });
        FilterCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FilterCbActionPerformed(evt);
            }
        });
        jPanel1.add(FilterCb, new org.netbeans.lib.awtextra.AbsoluteConstraints(411, 476, 187, 40));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setText("Items List");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(431, 411, 155, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel8.setText("Filter");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(239, 484, 133, -1));

        Addbtn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Addbtn.setText("Add");
        Addbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddbtnActionPerformed(evt);
            }
        });
        jPanel1.add(Addbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(431, 310, -1, -1));

        Deletebtn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Deletebtn.setText("Delete");
        Deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeletebtnActionPerformed(evt);
            }
        });
        jPanel1.add(Deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(166, 310, -1, -1));

        Editbtn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Editbtn.setText("Edit");
        Editbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditbtnActionPerformed(evt);
            }
        });
        jPanel1.add(Editbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(627, 310, -1, -1));

        Productlist.setBackground(new java.awt.Color(255, 204, 255));
        Productlist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Category", "Price"
            }
        ));
        Productlist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ProductlistMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Productlist);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 546, 593, 286));

        Refreshbtn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Refreshbtn.setText("Refresh");
        Refreshbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshbtnActionPerformed(evt);
            }
        });
        jPanel1.add(Refreshbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(829, 306, -1, -1));

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setText("Log Out");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 720, -1, -1));

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton2.setText("Next Page");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 610, -1, -1));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 1070, 880));

        jButton3.setText("jButton3");
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 730, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, 1070, 880));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddbtnActionPerformed
       CountProd();
        if(prName.getText().isEmpty() || prPrc.getText().isEmpty() || prCategory.getSelectedIndex()==-1){
           JOptionPane.showMessageDialog(this,"Missing Information!!!");
        }
        else{
            try {
                
          
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pizza","root","root");
                PreparedStatement pst=con.prepareStatement("Insert into ProductTable values(?,?,?,?)");
                pst.setInt(1, PrNum);
                pst.setString(2,prName.getText());
                 pst.setString(3,prCategory.getSelectedItem().toString());
                 

                  pst.setInt(4,Integer.valueOf(prPrc.getText()));
                  int row=pst.executeUpdate();
                  JOptionPane.showMessageDialog(this,"Item added!!!");
                  con.close();
                 ShowProducts();
                 
            }
             catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,ex);
            }
        }
    }//GEN-LAST:event_AddbtnActionPerformed
int Key=0;
    private void ProductlistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProductlistMouseClicked
        DefaultTableModel model=(DefaultTableModel) Productlist.getModel();
       int MyIndex=Productlist.getSelectedRow();
       Key=Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
       prName.setText(model.getValueAt(MyIndex,1).toString());
      // prName.setText(model.getValueAt(MyIndex,1).toString());
       prPrc.setText(model.getValueAt(MyIndex,3).toString());
    }//GEN-LAST:event_ProductlistMouseClicked

    private void EditbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditbtnActionPerformed
        if(prName.getText().isEmpty() || prPrc.getText().isEmpty() || prCategory.getSelectedIndex()==-1){
           JOptionPane.showMessageDialog(this,"Missing Information!!!");
        }
        else{
            try {
                
           CountProd();
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pizza","root","root");
                PreparedStatement pst=con.prepareStatement("update ProductTable set PName=?,Category=?,price=? where PNum=?");
                pst.setInt(4, Key);
                pst.setString(1,prName.getText());
                 pst.setString(2,prCategory.getSelectedItem().toString());
                 pst.setInt(3, Integer.valueOf(prPrc.getText()));
                  int row=pst.executeUpdate();
                  JOptionPane.showMessageDialog(this,"Item Updated!!!");
                  con.close();
                  ShowProducts();
                 
            }
             catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,ex);
            }
        }
    }//GEN-LAST:event_EditbtnActionPerformed

    private void DeletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeletebtnActionPerformed
         if(prName.getText().isEmpty() || prPrc.getText().isEmpty() || prCategory.getSelectedIndex()==-1){
           JOptionPane.showMessageDialog(this,"Missing Information!!!");
        }
        else{
            try {
                
           CountProd();
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pizza","root","root");
                PreparedStatement pst=con.prepareStatement("delete from ProductTable where PNum=?");
                pst.setInt(1, Key);
                
                  int row=pst.executeUpdate();
                  JOptionPane.showMessageDialog(this,"Item Deleted!!!");
                  con.close();
                  ShowProducts();
                 
            }
             catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,ex);
            }
        }
    }//GEN-LAST:event_DeletebtnActionPerformed

    private void FilterCbItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_FilterCbItemStateChanged
        FilterProducts();
    }//GEN-LAST:event_FilterCbItemStateChanged

    private void RefreshbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshbtnActionPerformed
         ShowProducts();
    }//GEN-LAST:event_RefreshbtnActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        new Identity().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      new Selling().setVisible(true);
      this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void FilterCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterCbActionPerformed
          FilterProducts();
    }//GEN-LAST:event_FilterCbActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Items().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Addbtn;
    private javax.swing.JButton Deletebtn;
    private javax.swing.JButton Editbtn;
    private javax.swing.JComboBox<String> FilterCb;
    private javax.swing.JTable Productlist;
    private javax.swing.JButton Refreshbtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> prCategory;
    private javax.swing.JTextField prName;
    private javax.swing.JTextField prPrc;
    // End of variables declaration//GEN-END:variables
}
