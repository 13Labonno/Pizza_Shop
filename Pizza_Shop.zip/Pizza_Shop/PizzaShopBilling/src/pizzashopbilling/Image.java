/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pizzashopbilling;

import java.text.MessageFormat;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Asus
 */
public class Image extends javax.swing.JFrame {

    /**
     * Creates new form Image
     */
    public Image() {
        initComponents();
    }

      public void ItemCost(){
        double sum=0;
        for(int i=0;i< jTable1.getRowCount();i++){
            sum=sum+Double.parseDouble(jTable1.getValueAt(i, 2).toString());
        }
            jtxtSubTotal.setText(Double.toString(sum));
            double cTotal1=Double.parseDouble(jtxtSubTotal.getText());
            double cDiscount=(cTotal1 *2)/100;
            String iDiscountTotal=String.format("%.2f", cDiscount);
            jtxtDiscount.setText(iDiscountTotal);
            String iSubTotal=String.format("%.2f", cTotal1);
            jtxtSubTotal.setText(iSubTotal);
            String iTotal=String.format("%.2f", cTotal1-cDiscount);
            jtxtTotal.setText(iTotal);
            
        
    }
    public void Change(){
        double sum=0;
        double discount=2;
        double cash=Double.parseDouble(jtxtDisplay.getText());
        
        for(int i=0;i< jTable1.getRowCount();i++){
          // sum=sum+Double.parseDouble(jTable1.getValueAt(i, 2).toString());
          String value = jTable1.getValueAt(i, 2).toString();
if(value != null){
  sum = sum + Double.parseDouble(value);
}
        }     
            double cDiscount=(sum*2)/100;
            double cChange=(cash-(sum+cDiscount));
            String ChangeGiven=String.format("%.2f", cChange);
            jtxtChange.setText(ChangeGiven);
        
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jbtn9 = new javax.swing.JButton();
        jbtn7 = new javax.swing.JButton();
        jbtnC = new javax.swing.JButton();
        jbtn8 = new javax.swing.JButton();
        jbtn4 = new javax.swing.JButton();
        jbtn5 = new javax.swing.JButton();
        jbtn6 = new javax.swing.JButton();
        jbtn1 = new javax.swing.JButton();
        jbtn2 = new javax.swing.JButton();
        jbtn3 = new javax.swing.JButton();
        jbtn0 = new javax.swing.JButton();
        jbtnDot = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jbtnPizza1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        pizza2 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jtxtTotal = new javax.swing.JTextField();
        jtxtSubTotal = new javax.swing.JTextField();
        jtxtDiscount = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jtxtChange = new javax.swing.JTextField();
        jtxtDisplay = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jbtnPay = new javax.swing.JButton();
        jbtnReset = new javax.swing.JButton();
        jbtnPrint = new javax.swing.JButton();
        jbtnRemove = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtn9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn9.setText("9");
        jbtn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn9ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn9, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 20, 90, 66));

        jbtn7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn7.setText("7");
        jbtn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn7ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 90, 66));

        jbtnC.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtnC.setText("C");
        jbtnC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnC, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 90, 66));

        jbtn8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn8.setText("8");
        jbtn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn8ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 90, 66));

        jbtn4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn4.setText("4");
        jbtn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn4ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 90, 66));

        jbtn5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn5.setText("5");
        jbtn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn5ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, 90, 66));

        jbtn6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn6.setText("6");
        jbtn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn6ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 90, 66));

        jbtn1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn1.setText("1");
        jbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn1ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 90, 66));

        jbtn2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn2.setText("2");
        jbtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn2ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 200, 90, 66));

        jbtn3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn3.setText("3");
        jbtn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn3ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 200, 90, 66));

        jbtn0.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtn0.setText("0");
        jbtn0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn0ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn0, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 90, 66));

        jbtnDot.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtnDot.setText(".");
        jbtnDot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnDotActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnDot, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 90, 66));

        jTable1.setBackground(new java.awt.Color(153, 255, 204));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Pizza", "Quantity", "Amount"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnPizza1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtnPizza1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pizzashopbilling/pizza.png"))); // NOI18N
        jbtnPizza1.setText("199tk");
        jbtnPizza1.setToolTipText("");
        jbtnPizza1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnPizza1ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnPizza1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 300, 370));

        jPanel3.setBackground(new java.awt.Color(204, 255, 204));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel3.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, 90, 66));

        jButton16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel3.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 90, 66));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 40, 430, 490));

        jPanel4.setBackground(new java.awt.Color(204, 255, 204));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel4.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, 90, 66));

        jButton18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel4.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 90, 66));

        jPanel5.setBackground(new java.awt.Color(204, 255, 204));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel5.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, 90, 66));

        jButton20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel5.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 90, 66));

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 40, 430, 490));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 40, 430, 490));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Chicago Pizza");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 390, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Italian Pizza");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 390, 120, -1));

        pizza2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        pizza2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pizzashopbilling/p.1.jpg"))); // NOI18N
        pizza2.setToolTipText("");
        pizza2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pizza2ActionPerformed(evt);
            }
        });
        jPanel1.add(pizza2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, 290, 370));

        jPanel7.setBackground(new java.awt.Color(204, 204, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Total");
        jPanel7.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 60, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Price");
        jPanel7.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 60, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Discount");
        jPanel7.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 80, -1));
        jPanel7.add(jtxtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, 160, 30));
        jPanel7.add(jtxtSubTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, 160, 30));
        jPanel7.add(jtxtDiscount, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 160, 30));

        jPanel8.setBackground(new java.awt.Color(204, 204, 255));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Payment Method");
        jPanel8.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 150, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Cash");
        jPanel8.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 70, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Change");
        jPanel8.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 90, -1));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cash", "Visa Card" }));
        jPanel8.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, 270, 30));
        jPanel8.add(jtxtChange, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 270, 30));

        jtxtDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtDisplayActionPerformed(evt);
            }
        });
        jPanel8.add(jtxtDisplay, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 270, 30));

        jPanel6.setBackground(new java.awt.Color(204, 204, 255));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnPay.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtnPay.setText("Pay");
        jbtnPay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnPayActionPerformed(evt);
            }
        });
        jPanel6.add(jbtnPay, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        jbtnReset.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtnReset.setText("Reset");
        jbtnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnResetActionPerformed(evt);
            }
        });
        jPanel6.add(jbtnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, -1, -1));

        jbtnPrint.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtnPrint.setText("Print");
        jbtnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnPrintActionPerformed(evt);
            }
        });
        jPanel6.add(jbtnPrint, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 160, 90, -1));

        jbtnRemove.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jbtnRemove.setText("Back");
        jbtnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnRemoveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addComponent(jbtnRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(73, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jbtnRemove)
                        .addGap(14, 14, 14))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 9, Short.MAX_VALUE)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn9ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn9.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn9.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn9ActionPerformed

    private void jbtn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn7ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn7.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn7.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
            //jtxtDisplay.setText (Enternumber);

        }
    }//GEN-LAST:event_jbtn7ActionPerformed

    private void jbtnCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCActionPerformed
        jtxtDisplay.setText(" ");
        jtxtChange.setText("");
    }//GEN-LAST:event_jbtnCActionPerformed

    private void jbtn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn8ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn8.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn8.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn8ActionPerformed

    private void jbtn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn4ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn4.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn4.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn4ActionPerformed

    private void jbtn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn5ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn5.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn5.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn5ActionPerformed

    private void jbtn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn6ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn6.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn6.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn6ActionPerformed

    private void jbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn1ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn1.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn1.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn1ActionPerformed

    private void jbtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn2ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn2.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn2.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn2ActionPerformed

    private void jbtn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn3ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn3.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn3.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn3ActionPerformed

    private void jbtn0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn0ActionPerformed
        String Enternumber = jtxtDisplay.getText();
        if(Enternumber==" "){
            jtxtDisplay.setText(jbtn0.getText());
        }
        else{
            Enternumber=jtxtDisplay.getText()+jbtn0.getText();

            //Enternumber = txtDisplay.getText() itxtDisplay.getText() + jbtn7.getText();
            jtxtDisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn0ActionPerformed

    private void jbtnDotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnDotActionPerformed
        if(!jtxtDisplay.getText().contains(".")){
            jtxtDisplay.setText(jtxtDisplay.getText() + jbtnDot.getText());
        }
    }//GEN-LAST:event_jbtnDotActionPerformed

    private void jbtnPizza1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnPizza1ActionPerformed
        double priceOfItem=199;
        try{
            DefaultTableModel model=(DefaultTableModel )jTable1.getModel();
            model.addRow(new Object[]{"Italian Pizza" , "1" , priceOfItem});
            ItemCost();
        }catch(Exception e){
            System.out.println(e);
        }
    }//GEN-LAST:event_jbtnPizza1ActionPerformed

    private void pizza2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pizza2ActionPerformed
        double priceOfItem=299;
        try{
            DefaultTableModel model=(DefaultTableModel )jTable1.getModel();
            model.addRow(new Object[]{"Chicago Pizza" ,"1" , priceOfItem});
            ItemCost();
        }catch(Exception e){
            System.out.println(e);
        }
    }//GEN-LAST:event_pizza2ActionPerformed

    private void jtxtDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtDisplayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDisplayActionPerformed

    private void jbtnPayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnPayActionPerformed
        if(jComboBox1.getSelectedItem().equals("Cash")){
            Change();
        }
        else{
            jtxtChange.setText("");
            jtxtDisplay.setText("");
        }
    }//GEN-LAST:event_jbtnPayActionPerformed

    private void jbtnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnResetActionPerformed
        DefaultTableModel model=(DefaultTableModel )jTable1.getModel();
        model.setRowCount(0);
        jtxtChange.setText("");
        jtxtDiscount.setText(" ");
        jtxtTotal.setText(" ");
        jtxtSubTotal.setText(" ");
        jtxtDisplay.setText(" ");

    }//GEN-LAST:event_jbtnResetActionPerformed

    private void jbtnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnPrintActionPerformed
        MessageFormat header=new MessageFormat("Printing is Processing");
        MessageFormat footer=new MessageFormat("Page {0,number,integer}");
        try{
            jTable1.print(JTable.PrintMode.NORMAL,header,footer);

        }
        catch(Exception e){

        }
    }//GEN-LAST:event_jbtnPrintActionPerformed

    private void jbtnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnRemoveActionPerformed
        new CustomerLogIn().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jbtnRemoveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Image.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Image.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Image.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Image.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Image().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton20;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton jbtn0;
    private javax.swing.JButton jbtn1;
    private javax.swing.JButton jbtn2;
    private javax.swing.JButton jbtn3;
    private javax.swing.JButton jbtn4;
    private javax.swing.JButton jbtn5;
    private javax.swing.JButton jbtn6;
    private javax.swing.JButton jbtn7;
    private javax.swing.JButton jbtn8;
    private javax.swing.JButton jbtn9;
    private javax.swing.JButton jbtnC;
    private javax.swing.JButton jbtnDot;
    private javax.swing.JButton jbtnPay;
    private javax.swing.JButton jbtnPizza1;
    private javax.swing.JButton jbtnPrint;
    private javax.swing.JButton jbtnRemove;
    private javax.swing.JButton jbtnReset;
    private javax.swing.JTextField jtxtChange;
    private javax.swing.JTextField jtxtDiscount;
    private javax.swing.JTextField jtxtDisplay;
    private javax.swing.JTextField jtxtSubTotal;
    private javax.swing.JTextField jtxtTotal;
    private javax.swing.JButton pizza2;
    // End of variables declaration//GEN-END:variables
}
